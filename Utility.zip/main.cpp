#include "utPermutation.h"
#include "utPermutation.cpp"

int main()
{
	vector<int> data1 = { 1,2,3 };
	utPermutation<int> perm(data1);
	perm.allpermutation();
	perm.print_permutation();


	return 0;
}