#pragma once
#include <iostream>
#include <vector>
#include <iterator>
#include "algorithm"

using namespace std;

template <typename T>
class utPermutation
{
private:
	vector<T>  origin_data;
	vector<vector<T>>  permutated_data;
	void swap(T& a, T& b);
public:
	utPermutation(vector<T> data) :origin_data(data) {}
	utPermutation(vector<T> data, int r);
	void permutation(int depth, int n, int r);
	void allpermutation();
	vector<vector<T>> get_permutation();
	void print_permutation();
};

